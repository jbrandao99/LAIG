/**
* Animation
* @constructor
*/


class MyAnimation {
    constructor(scene){
        this.scene = scene;
    }


    update(){};

    apply(){};

}
